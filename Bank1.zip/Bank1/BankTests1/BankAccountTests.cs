﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankAccountNS;
namespace BankTests
{
    [TestClass]
    public class BankAccountTests
    {
        [TestMethod]
        public void Debit_WithValidAmount_UpdatesBalance()
        {
            // Arrange
            double beginningBalance = 11.99;
            double debitAmount = 4.55;
            double expected = 7.44;
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);
            // Act
            account.Debit(debitAmount);
            // Assert
            double actual = account.Balance;
            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        [TestMethod]
        public void Debit_WhenAmountIsLessThanZero_ShouldThrowArgumentOutOfRange()
        {
            // Arrange
            double beginningBalance = 11.99;
            double debitAmount = -100.00;
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);
            // Act and assert
            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() =>
            account.Debit(debitAmount));
        }
        [TestMethod]
        public void Debit_WhenAmountIsMoreThanBalance_ShouldThrowArgumentOutOfRange()
        {
            // Arrange
            double beginningBalance = 11.99;
            double debitAmount = 20.0;
            BankAccount account = new BankAccount("Mr. Bryan Walton", beginningBalance);

            // Act
            try
            {
                account.Debit(debitAmount);
            }
            catch (System.ArgumentOutOfRangeException e)
            {
                // Assert
                StringAssert.Contains(e.Message, BankAccount.DebitAmountExceedsBalanceMessage);
                return;
            }

            Assert.Fail("The expected exception was not thrown.");
        }
        [TestMethod]
        public void BankAccount_InitialBalance_SetCorrectly()
        {
            // Arrange
            double initialBalance = 100.0;
            string customerName = "John Doe";

            // Act
            BankAccount account = new BankAccount(customerName, initialBalance);

            // Assert
            Assert.AreEqual(initialBalance, account.Balance, 0.001, "Initial balance was not set correctly.");
        }
        [TestMethod]
        public void Credit_WithPositiveAmount_IncreasesBalance()
        {
            // Arrange
            double initialBalance = 50.0;
            double creditAmount = 25.0;
            double expectedBalance = initialBalance + creditAmount;
            BankAccount account = new BankAccount("Jane Smith", initialBalance);

            // Act
            account.Credit(creditAmount);

            // Assert
            Assert.AreEqual(expectedBalance, account.Balance, 0.001, "Balance was not increased correctly by Credit method.");
        }
        [TestMethod]
        public void Credit_WithNegativeAmount_ThrowsException()
        {
            // Arrange
            double initialBalance = 50.0;
            double creditAmount = -10.0;
            BankAccount account = new BankAccount("Alice Johnson", initialBalance);

            // Act and Assert
            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => account.Credit(creditAmount));
        }


    }
}